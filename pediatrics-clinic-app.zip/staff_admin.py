# Stub for staff admin and wage
