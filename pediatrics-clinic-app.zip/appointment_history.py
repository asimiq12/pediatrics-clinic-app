# Stub for appointment history
