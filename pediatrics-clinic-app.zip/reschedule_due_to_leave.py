# Stub for emergency leave handling
