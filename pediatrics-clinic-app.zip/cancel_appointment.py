# Stub for appointment cancellation
