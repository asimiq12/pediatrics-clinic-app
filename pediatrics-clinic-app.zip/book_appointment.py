# Stub for appointment booking module
