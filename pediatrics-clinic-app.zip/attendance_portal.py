# Stub for attendance with geolocation
