# Stub for appointment rescheduling
